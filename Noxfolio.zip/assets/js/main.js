$(document).ready(function(){
    $('.info-bar').click(function(){
        $('.extra-info').addClass('info-open');
    })

    $('.close-icon').click(function(){
        $('.extra-info').removeClass('info-open');
    })



    // counter js 
    $('.counter').counterUp({
        delay: 10,
        time: 4000
    });


    // slick js
    $('.testimonial-active').slick({
        slidesToShow: 2,
        slidesToScroll: 1,
        autoplay: false,
        autoplaySpeed: 2000,
        prevArrow: '<span class="prev_arrow"><i class="fa fa-left-long"></i></span>',
        nextArrow: '<span class="next_arrow"><i class="fa fa-right-long"></i></span>',
      });


      const accordionItems = document.querySelectorAll(".accordion-item");
      
      accordionItems.forEach(item => {
        const title = item.querySelector(".accordion-title");
        const content = item.querySelector(".accordion-content");

        title.addEventListener('click' ,() => {
            item.classList.toggle('active');
        });
      });


      // init Isotope
            var $grid = $('.portfolio-items').isotope({
                // options
            });
            // filter items on button click
            $('.portfolio-menu').on( 'click', 'li', function() {
                var filterValue = $(this).attr('data-filter');
                $grid.isotope({ filter: filterValue });
            });

});
